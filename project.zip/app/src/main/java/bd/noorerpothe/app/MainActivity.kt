package bd.noorerpothe.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val green = Color.parseColor("#0B6B4F")
    private val bg = Color.parseColor("#F4F8F5")
    private lateinit var toggleBtn: Button
    private lateinit var statusText: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.parseColor("#D5E4DB"))
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(14), dp(6), dp(14), dp(6)) }
    }

    private fun text(s: String, size: Float, color: Int = Color.parseColor("#222222"), bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(green)
            setPadding(dp(16), dp(28), dp(16), dp(20))
        }
        header.addView(text("নূরের পথে", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        header.addView(text("প্রতিদিনের ইসলামিক স্মরণবার্তা", 14f, Color.parseColor("#CFE8DC")).apply { gravity = Gravity.CENTER })
        root.addView(header)

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(24))
        }

        // সন্ধ্যার রিমাইন্ডার কার্ড
        val rc = card()
        rc.addView(text("🌆 সন্ধ্যার পাঠের স্মরণবার্তা", 18f, green, true))
        rc.addView(text("প্রতিদিন সন্ধ্যা ৬:৩০ থেকে রাত ৮:৪৫ পর্যন্ত প্রতি ১৫ মিনিট পরপর মোট ১০টি স্মরণবার্তা আসবে।", 14f).apply { setPadding(0, dp(6), 0, dp(6)) })
        statusText = text("", 14f, Color.parseColor("#555555"))
        rc.addView(statusText)
        toggleBtn = Button(this).apply { setOnClickListener { onToggle() } }
        rc.addView(toggleBtn)
        list.addView(rc)

        val sched = card()
        sched.addView(text("সময়সূচি", 16f, green, true))
        readings.forEach {
            val t = if (it.hour > 12) it.hour - 12 else it.hour
            val period = if (it.hour < 20) "সন্ধ্যা" else "রাত"
            sched.addView(text("$period $t:${it.minute.toString().padStart(2, '0')} — ${it.name}", 14f).apply { setPadding(0, dp(3), 0, dp(3)) })
        }
        list.addView(sched)

        list.addView(text("দৈনন্দিন জীবনের দোয়া", 18f, green, true).apply { setPadding(dp(18), dp(14), dp(18), dp(4)) })

        duaList.forEach { d ->
            val c = card()
            c.addView(text("${d.emoji} ${d.title}", 17f, green, true))
            c.addView(text(d.whenText, 12f, Color.parseColor("#777777")))
            c.addView(text(d.arabic, 22f).apply {
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                setPadding(0, dp(10), 0, dp(8))
            })
            c.addView(text("অর্থ: ${d.meaning}", 14f, Color.parseColor("#333333")))
            list.addView(c)
        }

        list.addView(text("দোয়াগুলো সহিহ হাদিস থেকে নেওয়া। কোনো ভুল চোখে পড়লে আমাদের জানান।", 12f, Color.parseColor("#777777")).apply {
            setPadding(dp(18), dp(10), dp(18), dp(10))
        })

        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll)
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        val on = Reminder.isEnabled(this)
        toggleBtn.text = if (on) "স্মরণবার্তা বন্ধ করুন" else "স্মরণবার্তা চালু করুন"
        statusText.text = if (on) "✅ চালু আছে" else "⏸ বন্ধ আছে"
    }

    private fun onToggle() {
        if (Reminder.isEnabled(this)) {
            Reminder.setEnabled(this, false)
            Reminder.cancelAll(this)
            refresh()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        enable()
    }

    private fun enable() {
        Reminder.setEnabled(this, true)
        Reminder.scheduleAll(this)
        Toast.makeText(this, "স্মরণবার্তা চালু হয়েছে", Toast.LENGTH_SHORT).show()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) enable()
            else Toast.makeText(this, "নোটিফিকেশনের অনুমতি না দিলে স্মরণবার্তা আসবে না", Toast.LENGTH_LONG).show()
        }
    }
}
