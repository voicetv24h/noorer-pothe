package bd.noorerpothe.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Reminder {
    const val CHANNEL_ID = "noorer_reminders"
    private const val PREFS = "noorer_prefs"
    private const val KEY_ENABLED = "enabled"

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(ctx: Context, value: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun createChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, "সন্ধ্যার স্মরণবার্তা", NotificationManager.IMPORTANCE_DEFAULT)
        nm.createNotificationChannel(ch)
    }

    private fun pendingIntent(ctx: Context, index: Int): PendingIntent {
        val intent = Intent(ctx, ReminderReceiver::class.java).putExtra("index", index)
        return PendingIntent.getBroadcast(
            ctx, 100 + index, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun scheduleOne(ctx: Context, index: Int) {
        val r = readings[index]
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, r.hour)
            set(Calendar.MINUTE, r.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent(ctx, index))
    }

    fun scheduleAll(ctx: Context) {
        for (i in readings.indices) scheduleOne(ctx, i)
    }

    fun cancelAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in readings.indices) am.cancel(pendingIntent(ctx, i))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val index = intent.getIntExtra("index", -1)
        if (index !in readings.indices) return
        if (!Reminder.isEnabled(context)) return

        Reminder.createChannel(context)
        val r = readings[index]
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(context, Reminder.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(r.name)
            .setContentText(r.note)
            .setStyle(Notification.BigTextStyle().bigText(r.note))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            nm.notify(1000 + index, n)
        } catch (_: SecurityException) {
        }
        Reminder.scheduleOne(context, index)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Reminder.isEnabled(context)) Reminder.scheduleAll(context)
    }
}
